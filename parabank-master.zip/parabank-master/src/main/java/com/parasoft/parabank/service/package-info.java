@javax.xml.bind.annotation.XmlSchema(
        elementFormDefault=javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.parasoft.parabank.service;