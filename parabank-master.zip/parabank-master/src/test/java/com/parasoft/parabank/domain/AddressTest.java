package com.parasoft.parabank.domain;

import com.parasoft.parabank.test.util.AbstractBeanTestCase;

/**
 * @req PAR-26
 *
 */
public class AddressTest extends AbstractBeanTestCase<Address> { }
