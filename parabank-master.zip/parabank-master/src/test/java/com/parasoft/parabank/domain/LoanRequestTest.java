package com.parasoft.parabank.domain;

import com.parasoft.parabank.test.util.AbstractBeanTestCase;

public class LoanRequestTest extends AbstractBeanTestCase<LoanRequest> { }