package com.parasoft.parabank.domain;

import com.parasoft.parabank.test.util.AbstractBeanTestCase;

public class TransactionTest extends AbstractBeanTestCase<Transaction> { }
