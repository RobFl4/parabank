INSERT INTO Account (id, customer_id, type, balance) VALUES (201, 101, 0, 1000.00);
